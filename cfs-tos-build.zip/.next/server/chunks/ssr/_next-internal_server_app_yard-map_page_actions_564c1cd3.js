module.exports=[12365,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_yard-map_page_actions_564c1cd3.js.map