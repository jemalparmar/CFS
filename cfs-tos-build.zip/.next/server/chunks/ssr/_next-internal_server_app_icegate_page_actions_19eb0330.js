module.exports=[2999,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_icegate_page_actions_19eb0330.js.map