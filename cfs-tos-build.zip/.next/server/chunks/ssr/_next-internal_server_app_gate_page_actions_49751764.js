module.exports=[71651,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_gate_page_actions_49751764.js.map