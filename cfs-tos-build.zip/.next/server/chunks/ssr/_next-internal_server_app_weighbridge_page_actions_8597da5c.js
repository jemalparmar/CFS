module.exports=[41141,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_weighbridge_page_actions_8597da5c.js.map