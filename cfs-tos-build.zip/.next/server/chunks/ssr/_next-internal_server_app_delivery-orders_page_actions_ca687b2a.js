module.exports=[14941,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_delivery-orders_page_actions_ca687b2a.js.map